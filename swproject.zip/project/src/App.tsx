import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import TherapyOptions from './components/TherapyOptions';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main>
        <Hero />
        <TherapyOptions />
      </main>
      <Footer />
    </div>
  );
}

export default App;