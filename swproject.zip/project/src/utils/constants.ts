export const SITE_NAME = 'Fiji Community Counseling';

export const ROUTES = {
  HOME: '/',
  SERVICES: '/services',
  PAYMENT: '/payment',
  ABOUT: '/about',
  CONTACT: '/contact'
} as const;

export const SERVICES = [
  {
    title: 'Individual Counseling',
    description: 'One-on-one sessions with professional counselors',
    price: 80
  },
  {
    title: 'Group Therapy',
    description: 'Supportive group sessions with peers',
    price: 45
  },
  {
    title: 'Family Counseling',
    description: 'Sessions for families and relationships',
    price: 100
  }
];