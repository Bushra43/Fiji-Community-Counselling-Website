import React, { useState } from 'react';
import { CreditCard } from 'lucide-react';
import { PaymentDetails } from '../../types';
import PaymentInput from './PaymentInput';

const PaymentForm = () => {
  const [formData, setFormData] = useState<PaymentDetails>({
    cardNumber: '',
    expiry: '',
    cvc: '',
    name: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would integrate with your payment processor
    console.log('Processing payment:', formData);
  };

  const updateField = (field: keyof PaymentDetails) => (value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center justify-center mb-6">
          <CreditCard className="text-teal-600 mr-2" />
          <h2 className="text-2xl font-semibold text-gray-800">Payment Details</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <PaymentInput
            label="Card Holder Name"
            value={formData.name}
            onChange={updateField('name')}
            placeholder="John Doe"
          />

          <PaymentInput
            label="Card Number"
            value={formData.cardNumber}
            onChange={updateField('cardNumber')}
            placeholder="1234 5678 9012 3456"
          />

          <div className="grid grid-cols-2 gap-4">
            <PaymentInput
              label="Expiry Date"
              value={formData.expiry}
              onChange={updateField('expiry')}
              placeholder="MM/YY"
            />
            <PaymentInput
              label="CVC"
              value={formData.cvc}
              onChange={updateField('cvc')}
              placeholder="123"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-teal-600 text-white py-2 px-4 rounded-lg hover:bg-teal-700 transition-colors"
          >
            Pay Now
          </button>
        </form>
      </div>
    </div>
  );
};

export default PaymentForm;