import React from 'react';

interface PaymentInputProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  type?: string;
  required?: boolean;
}

const PaymentInput: React.FC<PaymentInputProps> = ({
  label,
  value,
  onChange,
  placeholder,
  type = 'text',
  required = true
}) => {
  return (
    <div>
      <label className="block text-gray-700 mb-2">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
        placeholder={placeholder}
        required={required}
      />
    </div>
  );
};

export default PaymentInput;