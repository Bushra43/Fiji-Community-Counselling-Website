import React from 'react';
import { Link } from 'react-router-dom';
import { Heart } from 'lucide-react';
import { SITE_NAME, ROUTES } from '../../utils/constants';

const Navbar = () => {
  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to={ROUTES.HOME} className="flex items-center space-x-2">
            <Heart className="text-teal-600" />
            <span className="text-xl font-semibold text-gray-800">{SITE_NAME}</span>
          </Link>
          <div className="flex space-x-6">
            <Link to={ROUTES.HOME} className="text-gray-600 hover:text-teal-600">Home</Link>
            <Link to={ROUTES.SERVICES} className="text-gray-600 hover:text-teal-600">Services</Link>
            <Link to={ROUTES.ABOUT} className="text-gray-600 hover:text-teal-600">About</Link>
            <Link to={ROUTES.CONTACT} className="text-gray-600 hover:text-teal-600">Contact</Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;