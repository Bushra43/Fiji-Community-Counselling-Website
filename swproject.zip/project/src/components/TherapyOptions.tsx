import React from 'react';
import { Users, Bot, Clock, Shield } from 'lucide-react';

export default function TherapyOptions() {
  return (
    <div className="py-16 bg-gray-50" id="specialists">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">Choose Your Path to Recovery</h2>
          <p className="mt-4 text-lg text-gray-600">We offer both human specialists and AI-powered support to help you on your journey</p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2">
          {/* Specialist Option */}
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="px-6 py-8">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-indigo-600" />
                <h3 className="ml-3 text-xl font-semibold text-gray-900">Licensed Specialists</h3>
              </div>
              <p className="mt-4 text-gray-600">Connect with experienced therapists specialized in addiction recovery</p>
              <ul className="mt-6 space-y-4">
                <li className="flex items-center">
                  <Shield className="h-5 w-5 text-green-500" />
                  <span className="ml-2">Licensed & certified professionals</span>
                </li>
                <li className="flex items-center">
                  <Clock className="h-5 w-5 text-green-500" />
                  <span className="ml-2">Flexible scheduling</span>
                </li>
              </ul>
              <button className="mt-8 w-full bg-indigo-600 text-white py-3 px-4 rounded-md hover:bg-indigo-700 transition duration-150">
                Book a Session
              </button>
            </div>
          </div>

          {/* AI Option */}
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="px-6 py-8">
              <div className="flex items-center">
                <Bot className="h-8 w-8 text-indigo-600" />
                <h3 className="ml-3 text-xl font-semibold text-gray-900">AI Therapy Assistant</h3>
              </div>
              <p className="mt-4 text-gray-600">24/7 support powered by advanced AI technology</p>
              <ul className="mt-6 space-y-4">
                <li className="flex items-center">
                  <Clock className="h-5 w-5 text-green-500" />
                  <span className="ml-2">Available anytime, anywhere</span>
                </li>
                <li className="flex items-center">
                  <Shield className="h-5 w-5 text-green-500" />
                  <span className="ml-2">Complete privacy & anonymity</span>
                </li>
              </ul>
              <button className="mt-8 w-full bg-indigo-600 text-white py-3 px-4 rounded-md hover:bg-indigo-700 transition duration-150">
                Start AI Session
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}