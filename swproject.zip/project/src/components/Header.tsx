import React from 'react';
import { Heart, Bot, Users } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-white shadow-sm">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Heart className="h-8 w-8 text-rose-600" />
            <span className="ml-2 text-xl font-semibold text-gray-900">RecoveryConnect</span>
          </div>
          <div className="flex space-x-4">
            <a href="#specialists" className="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">Find Specialists</a>
            <a href="#ai-therapy" className="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">AI Therapy</a>
            <a href="#about" className="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">About</a>
          </div>
        </div>
      </nav>
    </header>
  );
}