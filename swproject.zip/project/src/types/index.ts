// Common TypeScript interfaces and types
export interface Message {
  text: string;
  sender: 'user' | 'bot';
}

export interface PaymentDetails {
  cardNumber: string;
  expiry: string;
  cvc: string;
  name: string;
}