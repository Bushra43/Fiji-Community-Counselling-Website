export function initializeSignupForm() {
    const form = document.getElementById('signupForm');

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const signupData = {
            name: form.signupName.value,
            email: form.signupEmail.value,
            password: form.signupPassword.value
        };

        // In a real application, this would send data to a server
        console.log('Signup submitted:', signupData);
        alert('Signup successful! Please check your email to verify your account.');
        
        form.reset();
        document.getElementById('signupModal').style.display = 'none';
    });
}
