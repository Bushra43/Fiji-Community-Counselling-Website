document.addEventListener("DOMContentLoaded", () => {
    // Elements for Modals
    const signupModal = document.getElementById('signupModal');
    const loginModal = document.getElementById('loginModal');
    const bookingModal = document.getElementById('bookingModal');
    const closeButtons = document.querySelectorAll('.modal .close');

    const signupButton = document.getElementById('signupButton');
    const loginButton = document.getElementById('loginButton');

    // Open Signup Modal
    signupButton.addEventListener('click', () => {
        openModal(signupModal);
    });

    // Open Login Modal
    loginButton.addEventListener('click', () => {
        openModal(loginModal);
    });
    
    // Hero Buttons
    const bookSpecialistButton = document.getElementById('bookSpecialist');
    const tryAIButton = document.getElementById('tryAI');

    // Open Modals
    bookSpecialistButton.addEventListener('click', () => {
        openModal(bookingModal);
    });

    tryAIButton.addEventListener('click', () => {
        // Open AI chat modal when clicking on the AI button
        openAIChatModal();
    });

    // Close Modals
    closeButtons.forEach(button => {
        button.addEventListener('click', () => {
            closeModal(button.closest('.modal'));
        });
    });

    // Close Modal when clicking outside content
    document.addEventListener('click', (event) => {
        if (event.target.classList.contains('modal')) {
            closeModal(event.target);
        }
    });

    // Booking Form Submission
    const bookingForm = document.getElementById('bookingForm');
    bookingForm.addEventListener('submit', (event) => {
        event.preventDefault();
        alert(`Booking confirmed for ${document.getElementById('name').value}. Check your email for details.`);
        closeModal(bookingModal);
    });

    // Signup Form Submission
    const signupForm = document.getElementById('signupForm');
    signupForm.addEventListener('submit', (event) => {
        event.preventDefault();
        alert(`Signup successful for ${document.getElementById('signupName').value}. Check your email for confirmation.`);
        closeModal(signupModal);
    });

    // Login Form Submission
    const loginForm = document.getElementById('loginForm');
    loginForm.addEventListener('submit', (event) => {
        event.preventDefault();
        alert(`Login successful for ${document.getElementById('loginEmail').value}.`);
        closeModal(loginModal);
    });

    // Utility Functions
    function openModal(modal) {
        modal.style.display = "block";
    }

    function closeModal(modal) {
        modal.style.display = "none";
    }

    // Update Footer Year Dynamically
    const yearElement = document.getElementById('year');
    yearElement.textContent = new Date().getFullYear();
});

// AI Chat Logic
function openAIChatModal() {
    const aiChatModal = document.getElementById('aiChatModal');
    const messages = aiChatModal.querySelector('.messages');
    const sendMessageButton = aiChatModal.querySelector('#sendMessage');
    const userInput = aiChatModal.querySelector('#userInput');

    aiChatModal.style.display = 'block'; // Show the AI Chat modal

    // Close the AI Chat Modal
    const closeModalButton = aiChatModal.querySelector('.close');
    closeModalButton.addEventListener('click', () => {
        aiChatModal.style.display = 'none';
    });

    // Close Modal when clicking outside content
    document.addEventListener('click', (event) => {
        if (event.target === aiChatModal) {
            aiChatModal.style.display = 'none';
        }
    });

    // Add a New Message (both AI and user)
    const addMessage = (content, sender) => {
        const message = document.createElement('div');
        message.classList.add('message', `${sender}-message`);
        message.textContent = content;
        messages.appendChild(message);
        messages.scrollTop = messages.scrollHeight; // Auto-scroll to the bottom
    };

    // Handle Send Message
    sendMessageButton.addEventListener('click', () => {
        const userMessage = userInput.value.trim();
        if (userMessage) {
            addMessage(userMessage, 'user'); // User's message
            userInput.value = '';

            // Simulate AI Response
            setTimeout(() => {
                const aiResponse = getAIResponse(userMessage); // AI response based on user input
                addMessage(aiResponse, 'ai');
            }, 1000); // Simulate delay
        }
    });
}

// Basic AI Response Logic (Can be expanded with more complex AI)
function getAIResponse(userMessage) {
    const lowerCaseMessage = userMessage.toLowerCase();

    // Simple responses based on keywords
    if (lowerCaseMessage.includes('hello') || lowerCaseMessage.includes('hi')) {
        return 'Hello! How can I assist you today?';
    } else if (lowerCaseMessage.includes('help')) {
        return 'I am here to help. Can you tell me more about what you need assistance with?';
    } else if (lowerCaseMessage.includes('how are you')) {
        return 'I am just a program, but thanks for asking! How can I help you today?';
    } else if (lowerCaseMessage.includes('book')) {
        return 'Would you like to book a session with a specialist? I can help you with that.';
    } else if (lowerCaseMessage.includes('thank you') || lowerCaseMessage.includes('thanks')) {
        return 'You\'re welcome! Let me know if you need anything else.';
    } else if (lowerCaseMessage.includes('bye') || lowerCaseMessage.includes('goodbye')) {
        return 'Goodbye! I hope you have a great day. Feel free to come back anytime.';
    } else if (lowerCaseMessage.includes('appointment')) {
        return 'I can assist with appointment bookings. Please let me know when you would like to schedule.';
    } else if (lowerCaseMessage.includes('therapy')) {
        return 'I can guide you to our therapy services. Do you need help with booking an appointment?';
    } else if (lowerCaseMessage.includes('ai') || lowerCaseMessage.includes('artificial intelligence')) {
        return 'I am powered by AI to assist you! How can I make your experience better today?';
    } else if (lowerCaseMessage.includes('sick') || lowerCaseMessage.includes('illness')) {
        return 'I\'m sorry to hear that you\'re not feeling well. Would you like some guidance or help with booking a consultation?';
    } else if (lowerCaseMessage.includes('pain')) {
        return 'I understand pain can be tough. Would you like assistance with finding a specialist?';
    } else if (lowerCaseMessage.includes('stress') || lowerCaseMessage.includes('anxiety')) {
        return 'It\'s okay to feel stressed sometimes. I can suggest ways to relax or help with booking a session with a therapist.';
    } else if (lowerCaseMessage.includes('happy') || lowerCaseMessage.includes('good')) {
        return 'I\'m glad to hear you’re feeling good! How can I help make your day even better?';
    } else if (lowerCaseMessage.includes('support')) {
        return 'I can provide support in various areas. What kind of support are you looking for today?';
    } else if (lowerCaseMessage.includes('contact')) {
        return 'You can reach our support team at any time via the contact form or call us for more details.';
    } else {
        return 'I\'m here to help! Can you tell me more about how you\'re feeling?';
    }
}
