export function initializeAIChat() {
    const aiChatModal = document.getElementById('aiChatModal');
    const closeModal = aiChatModal.querySelector('.close');
    const sendMessageButton = document.getElementById('sendMessage');
    const userInput = document.getElementById('userInput');
    const messages = document.querySelector('.messages');

    // Show the AI Chat Modal
    document.getElementById('tryAI').addEventListener('click', () => {
        aiChatModal.style.display = 'block';
    });

    // Close the AI Chat Modal
    closeModal.addEventListener('click', () => {
        aiChatModal.style.display = 'none';
    });

    // Close Modal when clicking outside content
    document.addEventListener('click', (event) => {
        if (event.target === aiChatModal) {
            aiChatModal.style.display = 'none';
        }
    });

    // Add a New Message (both AI and user)
    const addMessage = (content, sender) => {
        const message = document.createElement('div');
        message.classList.add('message', `${sender}-message`);
        message.textContent = content;
        messages.appendChild(message);
        messages.scrollTop = messages.scrollHeight; // Auto-scroll to the bottom
    };

    // Handle Send Message
    sendMessageButton.addEventListener('click', () => {
        const userMessage = userInput.value.trim();
        if (userMessage) {
            addMessage(userMessage, 'user'); // User's message
            userInput.value = '';

            // Simulate AI Response
            setTimeout(() => {
                const aiResponse = `I'm here to help! Can you tell me more about how you're feeling?`;
                addMessage(aiResponse, 'ai');
            }, 1000); // Simulate delay
        }
    });
}
