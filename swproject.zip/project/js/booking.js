export function initializeBookingForm() {
    const form = document.getElementById('bookingForm');

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const formData = {
            name: form.name.value,
            email: form.email.value,
            date: form.date.value,
            time: form.time.value
        };

        // In a real application, this would send data to a server
        console.log('Booking submitted:', formData);
        alert('Thank you for booking! We will contact you shortly to confirm your appointment.');
        
        form.reset();
        document.getElementById('bookingModal').style.display = 'none';
    });
}