export function initializeModal() {
    const modal = document.getElementById('bookingModal');
    const btns = document.querySelectorAll('.book-session');
    const span = document.querySelector('.close');

    btns.forEach(btn => {
        btn.addEventListener('click', () => {
            modal.style.display = 'block';
        });
    });

    span.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });


    document.querySelectorAll('.close').forEach(btn => {
        btn.addEventListener('click', () => {
            btn.parentElement.parentElement.style.display = 'none';
        });
    });
    
    document.querySelector('#signupForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.querySelector('#name').value;
        const email = document.querySelector('#email').value;
        const password = document.querySelector('#password').value;
    
        if (password !== document.querySelector('#confirmPassword').value) {
            alert('Passwords do not match!');
            return;
        }
    
        console.log('Sign-Up Data:', { name, email, password });
        alert('User Registered Successfully!');
    });
    
    document.querySelector('#loginForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.querySelector('#loginEmail').value;
        const password = document.querySelector('#loginPassword').value;
    
        console.log('Login Data:', { email, password });
        alert('Login Successful!');
    });
    document.querySelectorAll('.book-therapist').forEach(button => {
        button.addEventListener('click', () => {
            alert('Booking feature coming soon!');
        });
    });
        
}