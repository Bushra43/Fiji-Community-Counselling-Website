export function initializeLoginForm() {
    const form = document.getElementById('loginForm');

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const loginData = {
            email: form.loginEmail.value,
            password: form.loginPassword.value
        };

        // In a real application, this would send data to a server
        console.log('Login submitted:', loginData);
        alert('Login successful! Redirecting you to your dashboard.');
        
        form.reset();
        document.getElementById('loginModal').style.display = 'none';
    });
}
